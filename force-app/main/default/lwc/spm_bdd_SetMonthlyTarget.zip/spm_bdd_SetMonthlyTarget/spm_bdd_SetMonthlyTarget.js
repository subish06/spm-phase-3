import { LightningElement, api, track,wire } from 'lwc';
import getTargetBDM from '@salesforce/apex/SPMController.getTargetBDM';
import getActualTarget from '@salesforce/apex/SPMController.getActualsTarget';
import getVarianceTarget from '@salesforce/apex/SPMController.getVarianceTarget';

export default class Spm_bdd_SetMonthlyTarget extends LightningElement {

    @api financialYear;
    @api currentBDD;
    @api selectedBDM;
    @api showSection;
    // @api financialYear = 'FY-21';
    // @api currentBDD = '005020000033g0MAAQ';
    // @api selectedBDM = '005020000033g0RAAQ';

    @track salesTargetData = [];
    @track actualTargetData = [];
    @track varianceData = [];

    get columns() {
        let columnList = [
            { label: "Business Unit / Month", fieldName: "busUnit", type: "text", typeAttributes: {} },
            { label: "Apr", fieldName: "Apr", type: "currency", sortable: true, cellAttributes: { alignment: 'center', iconName: { fieldName: 'trendIcon' }, iconPosition: 'right', class: 'slds-text-wrap' }, typeAttributes: {} },
            { label: "May", fieldName: "May", type: "currency", sortable: true, cellAttributes: { alignment: 'center', iconName: { fieldName: 'trendIcon' }, iconPosition: 'right', class: 'slds-text-wrap' }, typeAttributes: {} },
            { label: "Jun", fieldName: "Jun", type: "currency", sortable: true, cellAttributes: { alignment: 'center', iconName: { fieldName: 'trendIcon' }, iconPosition: 'right', class: 'slds-text-wrap' }, typeAttributes: {} },
            { label: "Jul", fieldName: "Jul", type: "currency", sortable: true, cellAttributes: { alignment: 'center', iconName: { fieldName: 'trendIcon' }, iconPosition: 'right', class: 'slds-text-wrap' }, typeAttributes: {} },
            { label: "Aug", fieldName: "Aug", type: "currency", sortable: true, cellAttributes: { alignment: 'center', iconName: { fieldName: 'trendIcon' }, iconPosition: 'right', class: 'slds-text-wrap' }, typeAttributes: {} },
            { label: "Sep", fieldName: "Sep", type: "currency", sortable: true, cellAttributes: { alignment: 'center', iconName: { fieldName: 'trendIcon' }, iconPosition: 'right', class: 'slds-text-wrap' }, typeAttributes: {} },
            { label: "Oct", fieldName: "Oct", type: "currency", sortable: true, cellAttributes: { alignment: 'center', iconName: { fieldName: 'trendIcon' }, iconPosition: 'right', class: 'slds-text-wrap' }, typeAttributes: {} },
            { label: "Nov", fieldName: "Nov", type: "currency", sortable: true, cellAttributes: { alignment: 'center', iconName: { fieldName: 'trendIcon' }, iconPosition: 'right', class: 'slds-text-wrap' }, typeAttributes: {} },
            { label: "Dec", fieldName: "Dec", type: "currency", sortable: true, cellAttributes: { alignment: 'center', iconName: { fieldName: 'trendIcon' }, iconPosition: 'right', class: 'slds-text-wrap' }, typeAttributes: {} },
            { label: "Jan", fieldName: "Jan", type: "currency", sortable: true, cellAttributes: { alignment: 'center', iconName: { fieldName: 'trendIcon' }, iconPosition: 'right', class: 'slds-text-wrap' }, typeAttributes: {} },
            { label: "Feb", fieldName: "Feb", type: "currency", sortable: true, cellAttributes: { alignment: 'center', iconName: { fieldName: 'trendIcon' }, iconPosition: 'right', class: 'slds-text-wrap' }, typeAttributes: {} },
            { label: "Mar", fieldName: "Mar", type: "currency", sortable: true, cellAttributes: { alignment: 'center', iconName: { fieldName: 'trendIcon' }, iconPosition: 'right', class: 'slds-text-wrap' }, typeAttributes: {} }
        ];
        columnList.push({ label: "Total", fieldName: "total", type: "currency", sortable: true, cellAttributes: { alignment: 'center', iconName: { fieldName: 'trendIcon' }, iconPosition: 'right', class: 'slds-text-wrap' }, typeAttributes: {} });
        return columnList;
    }

    connectedCallback() {
        console.log('financialYear===>', this.financialYear)
        console.log('currentBDD===>', this.currentBDD)
        console.log('selectedBDM===>', this.selectedBDM)
        // this.targetBDM();
        // this.actualTarget();
        // this.variance();
    }

    @wire(getTargetBDM, { financialYear: '$financialYear', currentUser: '$currentBDD', selectedUser: '$selectedBDM' })
    wiredTargetData(result) {
        this.wiredMyApexMethodResult = result;
        if (result.data) {
            // Handle successful data retrieval
            this.salesTargetData = [];

            let targetData = { id: 1, busUnit: "Total", Apr: 0, May: 0, Jun: 0, Jul: 0, Aug: 0, Sep: 0, Oct: 0, Nov: 0, Dec: 0, Jan: 0, Feb: 0, Mar: 0, total: 0, isFirst: false };

            let count = 2;
            for (let busUnit in result.data) {
                let salesTar = { ...result.data[busUnit], id: count, busUnit: busUnit, total: 0, isFirst: true };
                for (let month in result.data[busUnit]) {
                    salesTar.total += result.data[busUnit][month];
                    targetData[month] += result.data[busUnit][month];
                }
                targetData.total += salesTar.total;

                //salesTar.total = this.nFormatter(salesTar.total, 0);

                this.salesTargetData.push(salesTar);
                count++;
            }

            this.salesTargetData.push(targetData);

            for (let data of this.salesTargetData) {
                for (let key in data) {
                    if (key != 'id' && key != 'busUnit' && key != 'isFirst') {
                        data[key + 'Data'] = this.nFormatter(data[key], 0);
                    }
                }
            }

            console.log(JSON.stringify(this.salesTargetData));
            this.error = undefined;
        } else if (result.error) {
            // Handle error
            console.log('error===>', result.error);
            this.error = result.error;
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error while getting Records',
                    message: result.error.message,
                    variant: 'error'
                }),
            );
        }
    }

    @wire(getActualTarget, { financialYear: '$financialYear', currentUser: '$currentBDD', selectedUser: '$selectedBDM' })
    wiredActualsData(result) {
        this.wiredMyApexMethodResult = result;
        if (result.data) {
            // Handle successful data retrieval
            this.actualTargetData = [];

            let targetData = { id: 1, busUnit: "Total", Apr: 0, May: 0, Jun: 0, Jul: 0, Aug: 0, Sep: 0, Oct: 0, Nov: 0, Dec: 0, Jan: 0, Feb: 0, Mar: 0, total: 0, isFirst: false };

            let count = 2;
            for (let busUnit in result.data) {
                let salesTar = { ...result.data[busUnit], id: count, busUnit: busUnit, total: 0, isFirst: true };
                for (let month in result.data[busUnit]) {
                    salesTar.total += result.data[busUnit][month];
                    targetData[month] += result.data[busUnit][month];
                }
                targetData.total += salesTar.total;

                //salesTar.total = this.nFormatter(salesTar.total, 0);

                this.actualTargetData.push(salesTar);
                count++;
            }

            this.actualTargetData.push(targetData);

            for (let data of this.actualTargetData) {
                for (let key in data) {
                    if (key != 'id' && key != 'busUnit' && key != 'isFirst') {
                        data[key + 'Data'] = this.nFormatter(data[key], 0);
                    }
                }
            }

            console.log(JSON.stringify(this.actualTargetData));
            this.error = undefined;
        } else if (result.error) {
            // Handle error
            console.log('error===>', result.error);
            this.error = result.error;
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error while getting Records',
                    message: result.error.message,
                    variant: 'error'
                }),
            );
        }
    }

    @wire(getVarianceTarget, { financialYear: '$financialYear', currentUser: '$currentBDD', selectedUser: '$selectedBDM' })
    wiredVarianceData(result) {
        this.wiredMyApexMethodResult = result;
        if (result.data) {
            // Handle successful data retrieval
            this.varianceData = [];

            let targetData = { id: 1, busUnit: "Total", Apr: 0, May: 0, Jun: 0, Jul: 0, Aug: 0, Sep: 0, Oct: 0, Nov: 0, Dec: 0, Jan: 0, Feb: 0, Mar: 0, total: 0, isFirst: false };

            let count = 2;
            for (let busUnit in result.data) {
                let salesTar = { ...result.data[busUnit], id: count, busUnit: busUnit, total: 0, isFirst: true };
                for (let month in result.data[busUnit]) {
                    salesTar.total += result.data[busUnit][month];
                    targetData[month] += result.data[busUnit][month];
                }
                targetData.total += salesTar.total;

                //salesTar.total = this.nFormatter(salesTar.total, 0);

                this.varianceData.push(salesTar);
                count++;
            }

            this.varianceData.push(targetData);

            for (let data of this.varianceData) {
                for (let key in data) {
                    if (key != 'id' && key != 'busUnit' && key != 'isFirst') {
                        data[key + 'Data'] = this.nFormatter(data[key], 0);
                    }
                }
            }

            console.log(JSON.stringify(this.varianceData));
            this.error = undefined;
        } else if (result.error) {
            // Handle error
            console.log('error===>', result.error);
            this.error = result.error;
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error while getting Records',
                    message: result.error.message,
                    variant: 'error'
                }),
            );
        }
    }

    // targetBDM() {
    //     getTargetBDM({ financialYear: this.financialYear, currentUser: this.currentBDD, selectedUser: this.selectedBDM })
    //         .then(result => {
    //             console.log('Dataa===>', result)
    //             if (result) {
    //                 this.salesTargetData = [];
    //                 let targetData = { id: 1, busUnit: "Total", Apr: 0, May: 0, Jun: 0, Jul: 0, Aug: 0, Sep: 0, Oct: 0, Nov: 0, Dec: 0, Jan: 0, Feb: 0, Mar: 0, total: 0 };
    //                 let count = 2;
    //                 for (let busUnit in result) {
    //                     let salesTar = { ...result[busUnit], id: count, busUnit: busUnit, total: 0 };
    //                     for (let month in result[busUnit]) {
    //                         salesTar.total += result[busUnit][month];
    //                         targetData[month] += result[busUnit][month];
    //                     }
    //                     targetData.total += salesTar.total;

    //                     this.salesTargetData.push(salesTar);
    //                     count++;
    //                 }
    //                 this.salesTargetData.push(targetData);

    //                 for (let data of this.salesTargetData) {
    //                     for (let key in data) {
    //                         if (key != 'id' && key != 'busUnit' && key != 'isFirst') {
    //                             data[key + 'Data'] = this.nFormatter(data[key], 0);
    //                         }
    //                     }
    //                 }
    //                 // console.log('salesTargetData ===>',JSON.stringify(this.salesTargetData))
    //                 this.error = undefined;
    //             } else if (result.error) {
    //                 console.log('error===>', result.error);
    //                 this.error = result.error;
    //                 this.dispatchEvent(
    //                     new ShowToastEvent({
    //                         title: 'Error while getting Records',
    //                         message: result.error.message,
    //                         variant: 'error'
    //                     }),
    //                 );
    //             }
    //         })
    // }

    // actualTarget() {
    //     getActualTarget({ financialYear: this.financialYear, currentUser: this.currentBDD, selectedUser: this.selectedBDM })
    //         .then(result => {
    //             console.log('Dataa===>', result)
    //             if (result) {
    //                 this.actualTargetData = [];
    //                 let targetData = { id: 1, busUnit: "Total", Apr: 0, May: 0, Jun: 0, Jul: 0, Aug: 0, Sep: 0, Oct: 0, Nov: 0, Dec: 0, Jan: 0, Feb: 0, Mar: 0, total: 0 };
    //                 let count = 2;
    //                 for (let busUnit in result) {
    //                     let salesTar = { ...result[busUnit], id: count, busUnit: busUnit, total: 0 };
    //                     for (let month in result[busUnit]) {
    //                         salesTar.total += result[busUnit][month];
    //                         targetData[month] += result[busUnit][month];
    //                     }
    //                     targetData.total += salesTar.total;

    //                     this.actualTargetData.push(salesTar);
    //                     count++;
    //                 }
    //                 this.actualTargetData.push(targetData);

    //                 for (let data of this.actualTargetData) {
    //                     for (let key in data) {
    //                         if (key != 'id' && key != 'busUnit' && key != 'isFirst') {
    //                             data[key + 'Data'] = this.nFormatter(data[key], 0);
    //                         }
    //                     }
    //                 }
    //                 this.error = undefined;
    //             } else if (result.error) {
    //                 console.log('error===>', result.error);
    //                 this.error = result.error;
    //                 this.dispatchEvent(
    //                     new ShowToastEvent({
    //                         title: 'Error while getting Records',
    //                         message: result.error.message,
    //                         variant: 'error'
    //                     }),
    //                 );
    //             }
    //         })
    // }

    // variance() {
    //     getVarianceTarget({ financialYear: this.financialYear, currentUser: this.currentBDD, selectedUser: this.selectedBDM })
    //         .then(result => {
    //             console.log('Dataa===>', result)
    //             if (result) {
    //                 this.varianceData = [];
    //                 let targetData = { id: 1, busUnit: "Total", Apr: 0, May: 0, Jun: 0, Jul: 0, Aug: 0, Sep: 0, Oct: 0, Nov: 0, Dec: 0, Jan: 0, Feb: 0, Mar: 0, total: 0 };
    //                 let count = 2;
    //                 for (let busUnit in result) {
    //                     let salesTar = { ...result[busUnit], id: count, busUnit: busUnit, total: 0 };
    //                     for (let month in result[busUnit]) {
    //                         salesTar.total += result[busUnit][month];
    //                         targetData[month] += result[busUnit][month];
    //                     }
    //                     targetData.total += salesTar.total;

    //                     this.varianceData.push(salesTar);
    //                     count++;
    //                 }
    //                 this.varianceData.push(targetData);

    //                 for (let data of this.varianceData) {
    //                     for (let key in data) {
    //                         if (key != 'id' && key != 'busUnit' && key != 'isFirst') {
    //                             data[key + 'Data'] = this.nFormatter(data[key], 0);
    //                         }
    //                     }
    //                 }
    //                 console.log('Varianceee ===>',JSON.stringify(this.varianceData))
    //                 this.error = undefined;
    //             } else if (result.error) {
    //                 console.log('error===>', result.error);
    //                 this.error = result.error;
    //                 this.dispatchEvent(
    //                     new ShowToastEvent({
    //                         title: 'Error while getting Records',
    //                         message: result.error.message,
    //                         variant: 'error'
    //                     }),
    //                 );
    //             }
    //         })
    // }
  
    nFormatter(num, digits) {
        const lookup = [
            { value: 1, symbol: "" },
            { value: 1e3, symbol: "k" },
            { value: 1e6, symbol: "M" },
            { value: 1e9, symbol: "G" },
            { value: 1e12, symbol: "T" },
            { value: 1e15, symbol: "P" },
            { value: 1e18, symbol: "E" }
        ];
        const rx = /\.0+$|(\.[0-9]*[1-9])0+$/;
        var item = lookup.slice().reverse().find(function (item) {
            return num >= item.value;
        });
        return item ? (num / item.value).toFixed(digits).replace(rx, "$1") + item.symbol : "0";
    }

}